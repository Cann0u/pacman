# ****************************************************************************#
#                                                                             #
#                                                         :::      ::::::::   #
#    mazegen.py                                         :+:      :+:    :+:   #
#                                                     +:+ +:+         +:+     #
#    By: loursel <loursel@student.42.fr>            +#+  +:+       +#+        #
#                                                 +#+#+#+#+#+   +#+           #
#    Created: 2025/12/10 16:15:29 by loursel           #+#    #+#             #
#    Updated: 2025/12/22 13:00:25 by loursel          ###   ########.fr       #
#                                                                             #
# ****************************************************************************#

from enum import Enum
from collections import deque
from typing import List, Tuple, Generator, Any
from abc import ABC, abstractmethod
from copy import deepcopy
from pydantic import BaseModel, Field, model_validator, ValidationError
import random
import heapq
import os
import time
import dotenv
import sys


class MazeConfig(BaseModel):
    """
    Configuration model for maze generation parameters.

    This class defines and validates the configuration parameters needed to
    generate
    a maze, including dimensions, entry/exit points, and generation options.

    Attributes:
        height (int): The height of the maze in cells. Must be greater than 1.
        width (int): The width of the maze in cells. Must be greater than 1.
        entry_coord (tuple[int, int]): The (x, y) coordinates of the maze
        entry point.
        exit_coord (tuple[int, int]): The (x, y) coordinates of the maze exit
        point.
        output_file (str): The file path where the generated maze will be
        saved.
            Must be a non-empty string.
        perfect (bool): If True, generates a perfect maze (no loops, single
        solution).
            Defaults to False.
        visualize (bool): If True, enables visualization of the maze
        generation process.
            Defaults to False.
        seed (float | None): Optional random seed for reproducible maze
        generation.
            Defaults to None.

    Raises:
        ValueError: If entry and exit coordinates are the same.
        ValueError: If entry or exit x-coordinate exceeds the maze width.
        ValueError: If entry or exit y-coordinate exceeds the maze height.

    Examples:
        >>> config = MazeConfig(
        ...     height=10,
        ...     width=10,
        ...     entry_coord=(0, 0),
        ...     exit_coord=(9, 9),
        ...     output_file="maze.txt"
        ... )
    """

    height: int = Field(..., gt=1)
    width: int = Field(..., gt=1)
    entry_coord: tuple[int, int] = Field(...)
    exit_coord: tuple[int, int] = Field(...)
    output_file: str = Field(..., min_length=1)
    perfect: bool = Field(default=False)
    visualize: bool = Field(default=False)
    seed: float | None = Field(default=None)

    @model_validator(mode="after")
    def model_validator(self) -> Any:
        if self.entry_coord == self.exit_coord:
            raise ValueError("Exit and Entry have the same coordinates")
        x_exit, y_exit = self.exit_coord
        x_entry, y_entry = self.entry_coord
        if x_entry > self.width or x_exit > self.width:
            raise ValueError(
                f"{'Entry' if x_entry > self.width else 'Exit'}"
                f" coordinate on X is outside the map"
            )
        if y_entry > self.height or y_exit > self.height:
            raise ValueError(
                f"{'Entry' if y_entry > self.height else 'Exit'}"
                f" coordinate on Y is outside the map"
            )
        return self

    def __str__(self) -> str:
        return (
            f"Height: {self.height}\n"
            f"Width: {self.width}\n"
            f"Entry: {self.entry_coord}\n"
            f"Exit: {self.exit_coord}\n"
            f"Output File: {self.output_file}\n"
            f"Perfect: {self.perfect}"
        )


class Direction(Enum):
    """
    Enumeration representing the four cardinal directions in a maze.

    Attributes:
        N (str): North direction, represented by "N".
        E (str): East direction, represented by "E".
        W (str): West direction, represented by "W".
        S (str): South direction, represented by "S".
    """

    N = "N"
    E = "E"
    W = "W"
    S = "S"


class IGenerationAlgo(ABC):
    """
    Abstract base class for maze generation algorithms.

    This interface defines the contract for maze generation algorithms that
    produce mazes step-by-step, yielding intermediate states.

    Methods
    -------
    generate(entry: Tuple[int, int], exit_c: Tuple[int, int],
    maze: List[List[str]])
        -> Generator[List[List[str]], Any, List[List[str]]]
        Generate a maze between the given entry and exit points.

        Parameters
        ----------
        entry : Tuple[int, int]
            The (row, column) coordinates of the maze entry point.
        exit_c : Tuple[int, int]
            The (row, column) coordinates of the maze exit point.
        maze : List[List[str]]
            A 2D list representing the initial maze structure, where each cell
            contains a string character representing its state.

        Yields
        ------
        List[List[str]]
            Intermediate states of the maze during generation, allowing for
            visualization or step-by-step processing.

        Returns
        -------
        List[List[str]]
            The final generated maze structure.
    """

    @abstractmethod
    def generate(
        self,
        entry: Tuple[int, int],
        exit_c: Tuple[int, int],
        maze: List[List[str]],
    ) -> Generator[List[List[str]], Any, List[List[str]]]:
        pass


class IResolutionAlgo(ABC):
    """
    Abstract base class defining the interface for maze resolution algorithms.

    This interface establishes the contract that all maze resolution
    algorithms must follow,
    ensuring a consistent API for solving mazes regardless of the specific
    algorithm used.

    Methods
    -------
    resolve(maze: List[List[str]], entry: Tuple[int, int],
    exit: Tuple[int, int]) -> str
        Resolves the maze and returns a string representation of the solution
        path.

        Parameters
        ----------
        maze : List[List[str]]
            A 2D list representing the maze structure, where each cell
            contains a string
            indicating the type of cell (e.g., wall, path, etc.)
        entry : Tuple[int, int]
            The (row, column) coordinates of the maze entry point
        exit : Tuple[int, int]
            The (row, column) coordinates of the maze exit point

        Returns
        -------
        str
            A string representation of the solution path from entry to exit
    """

    @abstractmethod
    def resolve(
        self,
        maze: List[List[str]],
        entry: Tuple[int, int],
        exit: Tuple[int, int],
    ) -> str:
        pass


class RecursiveBacktracking(IGenerationAlgo):
    """
    Recursive Backtracking maze generation algorithm implementation.

    This class implements the recursive backtracking algorithm for maze
    generation,
    which creates a perfect maze (a maze with exactly one path between any two
    points)
    by randomly carving passages through walls while backtracking when dead
    ends are reached.

    The algorithm:
    1. Starts at the entry point and marks it as visited
    2. Randomly selects an unvisited neighbor cell (2 units away)
    3. Carves a path to that neighbor and moves to it
    4. Repeats steps 2-3 until no unvisited neighbors remain
    5. Backtracks to the previous cell and continues
    6. Finally carves an exit path

    Attributes:
        None

    Methods:
        generate: Creates a maze using recursive backtracking algorithm
        __get_unknown_cell: Finds unvisited neighboring cells 2 units away
        __carve_exit: Creates an exit path by removing a wall adjacent to
        visited cells
        __update_maze: Carves a path between two cells by marking intermediate
        cells

    The maze is represented as a 2D list where:
        - '#' represents walls
        - '*' represents passages/paths
    """

    def __init__(self) -> None:
        pass

    def __get_unknown_cell(
        self, maze: List[List[str]], current: Tuple[int, int]
    ) -> List[Tuple[int, int]]:
        """
        Get all unvisited neighboring cells that are 2 steps away from the
        current position.

        This method checks the four cardinal directions
        (left, down, right, up) from the
        current position, looking 2 cells away to find cells that are still
        marked as walls ('#').
        These represent unvisited cells in the maze generation algorithm.

        Args:
            maze (List[List[str]]): A 2D list representing the maze grid,
            where '#' represents
                                   walls/unvisited cells and other characters
                                   represent visited cells.
            current (Tuple[int, int]): The current position as (x, y)
            coordinates, where x is the
                                      column index and y is the row index.

        Returns:
            List[Tuple[int, int]]: A list of (x, y) coordinate tuples
            representing unvisited cells
                            that are 2 steps away from the current position.
                            The list may be
                            empty if no such cells exist or if they are out of
                            bounds.
        """
        x, y = current
        unknown = []
        if x >= 3 and maze[y][x - 2] == "#":
            unknown.append((x - 2, y))
        if y <= len(maze) - 3 and maze[y + 2][x] == "#":
            unknown.append((x, y + 2))
        if x <= len(maze[y]) - 3 and maze[y][x + 2] == "#":
            unknown.append((x + 2, y))
        if y >= 3 and maze[y - 2][x] == "#":
            unknown.append((x, y - 2))
        return unknown

    def __carve_exit(
        self, m: List[List[str]], exit_c: Tuple[int, int]
    ) -> List[List[str]]:
        """
        Carve an exit path in the maze by removing a wall adjacent to the exit
        coordinate.

        This method checks the four cardinal directions
        (left, up, right, down) from the
        exit coordinate and removes a wall ('#') if there is a valid path
        ('*') beyond it.
        Only one wall is carved in the first valid direction found.

        Args:
            m (List[List[str]]): A 2D list representing the maze where '#'
            represents walls
                                 and '*' represents paths.
            exit_c (Tuple[int, int]): The (x, y) coordinates of the exit
            position.

        Returns:
            List[List[str]]: The modified maze with the exit path carved.

        Note:
            The method checks boundaries (> 3 or < len - 3) to ensure there's
            enough space
            to verify a valid path exists beyond the wall to be carved.
        """
        x, y = exit_c
        if x > 3 and m[y][x - 1] == "#" and m[y][x - 2] == "*":
            m[y][x - 1] = "*"
        elif y > 3 and m[y - 1][x] == "#" and m[y - 2][x] == "*":
            m[y - 1][x] = "*"
        elif x < len(m[y]) - 3 and m[y][x + 1] == "#" and m[y][x + 2] == "*":
            m[y][x + 1] = "*"
        elif y < len(m) - 3 and m[y + 1][x] == "#" and m[y + 2][x] == "*":
            m[y + 1][x] = "*"
        return m

    def __update_maze(
        self,
        maze: List[List[str]],
        curr: Tuple[int, int],
        dest: Tuple[int, int],
    ) -> List[List[str]]:
        """
        Update the maze by marking a path from current position to
        destination position.

        This method marks cells along a straight line (horizontal,
        vertical, or diagonal)
        from the current position to the destination position with an
        asterisk ('*').

        Args:
            maze (List[List[str]]): A 2D list representing the maze grid
            where each cell
                contains a string character.
            curr (Tuple[int, int]): The starting position as a tuple of
            (x, y) coordinates.
            dest (Tuple[int, int]): The destination position as a tuple of
            (x, y) coordinates.

        Returns:
            List[List[str]]: The modified maze with the path marked from
            curr to dest.

        Note:
            This method assumes that the path between curr and dest is
            either horizontal,
            vertical, or diagonal. It moves one step at a time in the
            determined direction
            until reaching the destination.
        """
        dir_x = 1 if dest[0] > curr[0] else -1 if dest[0] < curr[0] else 0
        dir_y = 1 if dest[1] > curr[1] else -1 if dest[1] < curr[1] else 0
        x, y = curr
        while x != dest[0] or y != dest[1]:
            maze[y][x] = "*"
            x += dir_x
            y += dir_y
        maze[y][x] = "*"
        return maze

    def generate(
        self,
        entry: Tuple[int, int],
        exit_c: Tuple[int, int],
        maze: List[List[str]],
    ) -> Generator[List[List[str]], Any, List[List[str]]]:
        """
        Generate a maze using depth-first search with backtracking
        algorithm.

        This method creates a maze by iteratively visiting cells and
        carving paths between them.
        It yields intermediate states of the maze during generation and
        returns the final maze
        with an exit carved out.

        Args:
            entry (Tuple[int, int]): The starting coordinates
            (row, column) for maze generation.
            exit_c (Tuple[int, int]): The coordinates (row, column) where
            the exit should be carved.
            maze (List[List[str]]): The initial maze grid represented as a
            2D list of strings.

        Yields:
            List[List[str]]: Intermediate states of the maze as it's being
            generated, after each
                             cell is visited and a path is carved.

        Returns:
            List[List[str]]: The final maze with all paths carved and the
            exit created at the
                             specified exit coordinates.

        Note:
            - Uses a deque to maintain a stack of visited cells for
            backtracking
            - Randomly selects from available unknown neighbors to create
            maze paths
            - The algorithm continues until all reachable cells have been
            visited
        """
        visited_cell: deque[Tuple[int, int]] = deque([entry])
        while len(visited_cell) != 0:
            current_pos = visited_cell.popleft()
            unknown_neighbour = self.__get_unknown_cell(maze, current_pos)
            if len(unknown_neighbour) > 0:
                visited_cell.appendleft(current_pos)
                chosen: Tuple[int, int] = random.choice(unknown_neighbour)
                maze = self.__update_maze(maze, current_pos, chosen)
                visited_cell.appendleft(chosen)
                yield maze
        return self.__carve_exit(maze, exit_c)


class AStar(IResolutionAlgo):
    """
    A* pathfinding algorithm implementation for maze solving.

    This class implements the A* search algorithm to find the shortest path
    through a maze
    from an entry point to an exit point. The algorithm uses a heuristic
    function (Euclidean distance)
    to efficiently explore the maze.

    The maze is represented as a 2D grid where:
    - '*' represents a walkable cell
    - Other characters represent walls/blocked cells
    - Movement is restricted to 4 directions (North, South, East, West) with a
    step size of 2

    Attributes:
        __path (str): The computed path from entry to exit as a string of
        direction characters.

    Methods:
        is_valid(row, col, size_row, size_col): Checks if a cell position is
        within maze bounds.
        is_unblocked(row, col, maze, direction): Checks if a cell and the path
        to it are walkable.
        is_destination(dest, row, col): Checks if current position matches the
        destination.
        calculate_heuristic(row, col, dest): Calculates Euclidean distance to
        destination.
        resolve(maze, entry, exit_c): Finds and returns the path from entry to
        exit.

    Inner Classes:
        Cell: Represents a cell in the A* algorithm with parent references and
        f, g, h values.
    """

    class Cell:
        """
        Represents a cell in the A* pathfinding algorithm.

        Attributes:
            parent_i (int): The row index of the parent cell in the path.
            parent_j (int): The column index of the parent cell in the path.
            f (float): The total cost of the cell (f = g + h). Initialized to
            infinity.
            g (float): The cost from the start cell to this cell. Initialized
            to infinity.
            h (float): The heuristic cost from this cell to the destination
            cell. Initialized to 0.0.
        """

        def __init__(self) -> None:
            self.parent_i = 0
            self.parent_j = 0
            self.f = float("inf")
            self.g = float("inf")
            self.h: float = 0.0

    @staticmethod
    def is_valid(row: int, col: int, size_row: int, size_col: int) -> bool:
        """
        Check if the given row and column indices are within valid bounds of
        the maze.

        Args:
            row (int): The row index to validate.
            col (int): The column index to validate.
            size_row (int): The maximum number of rows in the maze.
            size_col (int): The maximum number of columns in the maze.

        Returns:
            bool: True if the position is within valid bounds (excluding
            borders), False otherwise.

        Note:
            This function checks if the position is strictly between 0 and the
            size limits,
            excluding the boundary cells (0 and size-1).
        """
        return (row > 0 and row < size_col) and (col > 0 and col < size_row)

    @staticmethod
    def is_unblocked(
        row: int,
        col: int,
        maze: List[List[str]],
        direction: Tuple[int, int],
    ) -> bool:
        """
        Check if a cell and its adjacent cell in the given direction are both
        unblocked.

        This method verifies that both the current cell and the cell in the
        specified
        direction are marked as unblocked (represented by "*") in the maze.

        Args:
            row (int): The row index of the current cell in the maze.
            col (int): The column index of the current cell in the maze.
            maze (List[List[str]]): A 2D list representing the maze grid,
            where "*"
                indicates an unblocked cell.
            direction (Tuple[int, int]): A tuple (x, y) representing the
            direction vector
                to check. The values are normalized to -1, 0, or 1.

        Returns:
            bool: True if both the current cell at (row, col) and the adjacent
            cell
                in the normalized direction are unblocked ("*"), False
                otherwise.

        Note:
            The direction tuple is normalized internally so that each
            component is
            converted to -1 (if negative), 1 (if positive), or 0 (if zero).
        """
        x, y = direction
        x = -1 if x > 0 else 1 if x < 0 else 0
        y = -1 if y > 0 else 1 if y < 0 else 0
        return maze[row][col] == "*" and maze[row + y][col + x] == "*"

    @staticmethod
    def is_destination(dest: Tuple[int, int], row: int, col: int) -> bool:
        """
        Check if the current position matches the destination coordinates.

        Args:
            dest (Tuple[int, int]): The destination coordinates as (x, y).
            row (int): The current row position (y-coordinate).
            col (int): The current column position (x-coordinate).

        Returns:
            bool: True if the current position (row, col) matches the
            destination,
                  False otherwise.

        Note:
            The function expects dest in (x, y) format while comparing with
            (col, row) to match the coordinate systems.
        """
        return row == dest[1] and col == dest[0]

    @staticmethod
    def calculate_heuristic(
        row: int, col: int, dest: Tuple[int, int]
    ) -> float:
        """
        Calculate the Euclidean distance heuristic between a position and
        destination.

        This method computes the straight-line (Euclidean) distance between a
        given
        position (row, col) and a destination point. This is commonly used as a
        heuristic function in pathfinding algorithms like A*.

        Args:
            row (int): The row coordinate of the current position.
            col (int): The column coordinate of the current position.
            dest (Tuple[int, int]): A tuple containing the (row, col)
            coordinates
                of the destination position.

        Returns:
            float: The Euclidean distance between the current position and the
                destination.
        """
        return float(((row - dest[0]) ** 2 + (col - dest[1]) ** 2) ** 0.5)

    def __init__(self) -> None:
        pass

    def _build_path(self, maze: Any, dest: Tuple[int, int]) -> None:
        """
        Build a path from the starting cell to the destination cell by
        backtracking through parent cells.

        This method traces back through the maze from the destination cell to
        the starting cell using
        parent references stored in each cell. It then converts the sequence
        of cells into a string
        of directional moves (N, S, E, W) and appends it to the internal path.

        Args:
            maze (Any): A 2D array-like structure where each cell contains
            parent_i and parent_j
                        attributes that point to the parent cell in the path.
            dest (Tuple[int, int]): The destination coordinates as (column,
            row) from which to
                                   start backtracking.

        Returns:
            None: The method modifies the internal __path attribute by
            appending directional
                  moves as a string.

        Note:
            - The method assumes cells are spaced 2 units apart (as indicated
            by the step size
              of 2 in the directions dictionary).
            - Direction values are obtained from the Direction enum's value
            attribute.
            - The path is built in reverse (from dest to start) then reversed
            to get the correct order.
        """
        cells = []
        col, row = dest

        while maze[row][col].parent_i != row or maze[row][col].parent_j != col:
            cells.append((row, col))
            temp_row = maze[row][col].parent_i
            temp_col = maze[row][col].parent_j
            row, col = temp_row, temp_col
        cells.append((row, col))
        cells = cells[::-1]

        directions = {
            (0, 2): Direction.E,
            (0, -2): Direction.W,
            (2, 0): Direction.S,
            (-2, 0): Direction.N,
        }
        for i in range(len(cells) - 1):
            next_y, next_x = cells[i + 1]
            curr_y, curr_x = cells[i]
            self.__path += directions[(next_y - curr_y, next_x - curr_x)].value

    def resolve(
        self,
        maze: List[List[str]],
        entry: Tuple[int, int],
        exit_c: Tuple[int, int],
    ) -> str:
        """
        Finds the shortest path in a maze using the A* pathfinding algorithm.

        This method implements the A* search algorithm to find an optimal path
        from an entry point
        to an exit point in a maze. It uses a heuristic function to guide the
        search and maintains
        lists of explored and unexplored cells.

        Args:
            maze (List[List[str]]): A 2D list representing the maze layout,
            where each cell
                contains a string indicating whether it's a wall or passage.
            entry (Tuple[int, int]): A tuple (j, i) representing the starting
            coordinates in
                the maze, where j is the column index and i is the row index.
            exit_c (Tuple[int, int]): A tuple (j, i) representing the
            destination coordinates
                in the maze, where j is the column index and i is the row
                index.

        Returns:
            str: A string representation of the path from entry to exit.
            Returns an empty
                string if no path is found.

        Note:
            - The algorithm explores cells in steps of 2 units (as indicated
            by the directions).
            - The method updates the private attribute `__path` with the found
            path.
            - A message "No path found to exit" is printed if the destination
            is unreachable.
        """
        self.__path = ""
        closed_list = [
            [False for _ in range(len(maze[0]))] for _ in range(len(maze))
        ]
        cell_details = [
            [AStar.Cell() for _ in range(len(maze[0]))]
            for _ in range(len(maze))
        ]
        j, i = entry
        cell_details[i][j].f = 0
        cell_details[i][j].g = 0
        cell_details[i][j].h = 0
        cell_details[i][j].parent_i = i
        cell_details[i][j].parent_j = j

        open_list: List[Tuple[float, int, int]] = []
        heapq.heappush(open_list, (0.0, i, j))
        found_dest = False

        directions = [(0, 2), (0, -2), (2, 0), (-2, 0)]
        while len(open_list) > 0:
            p = heapq.heappop(open_list)
            i = p[1]
            j = p[2]
            closed_list[i][j] = True

            for d_x, d_y in directions:
                new_i = i + d_y
                new_j = j + d_x
                if AStar.is_valid(
                    new_i, new_j, len(maze[0]), len(maze)
                ) and AStar.is_unblocked(new_i, new_j, maze, (d_x, d_y)):
                    if AStar.is_destination(exit_c, new_i, new_j):
                        cell_details[new_i][new_j].parent_i = i
                        cell_details[new_i][new_j].parent_j = j

                        found_dest = True
                        self._build_path(cell_details, exit_c)
                        return self.__path
                    else:
                        g_new = cell_details[i][j].g + 1.0
                        h_new = AStar.calculate_heuristic(new_i, new_j, exit_c)
                        f_new = g_new + h_new

                        if (
                            cell_details[i][j].f == float("inf")
                            or cell_details[new_i][new_j].f > f_new
                        ):
                            heapq.heappush(open_list, (f_new, new_i, new_j))
                            cell_details[new_i][new_j].f = f_new
                            cell_details[new_i][new_j].g = g_new
                            cell_details[new_i][new_j].h = h_new
                            cell_details[new_i][new_j].parent_i = i
                            cell_details[new_i][new_j].parent_j = j

        if not found_dest:
            print("No path found to exit")
            return self.__path
        return self.__path


class MazeGenerator:
    """
    A maze generator class that creates and solves mazes using configurable
    algorithms.

    This class generates a maze based on the provided configuration,
    optionally draws
    a "42" pattern in the center, and can solve the maze using a resolution
    algorithm.
    The maze can be generated as perfect (no loops) or imperfect (with
    additional paths).

    Attributes:
        maze (List[List[str]]): A deep copy of the generated maze as a 2D grid.
        path (str): The solution path from entry to exit.

    Args:
        config (MazeConfig): Configuration object containing maze parameters
        (width,
            height, entry/exit coordinates, seed, etc.).
        generation_algo (IGenerationAlgo, optional): Algorithm to generate the
        maze.
            Defaults to RecursiveBacktracking().
        resolution_algo (IResolutionAlgo, optional): Algorithm to solve the
        maze.
            Defaults to AStar().

    Methods:
        generate() -> Tuple[List[str], str]:
            Generates the maze and returns its hexadecimal representation and
            solution path.

        get_config(path: str) -> MazeConfig | None:
            Static method to load maze configuration from a .env file.

    Example:
        >>> config = MazeGenerator.get_config('.env')
        >>> if config:
        ...     generator = MazeGenerator(config)
        ...     hexa_maze, solution_path = generator.generate()
    """

    def __init__(
        self,
        config: MazeConfig,
        generation_algo: IGenerationAlgo = RecursiveBacktracking(),
        resolution_algo: IResolutionAlgo = AStar(),
    ) -> None:
        """
        Initialize a Maze instance with the specified configuration and
        algorithms.

        Args:
            config (MazeConfig): Configuration object containing maze
            parameters including
                width, height, seed, entry coordinates, and exit coordinates.
            generation_algo (IGenerationAlgo, optional): Algorithm used to
            generate the maze.
                Defaults to RecursiveBacktracking().
            resolution_algo (IResolutionAlgo, optional): Algorithm used to
            solve the maze.
                Defaults to AStar().

        Attributes:
            __config (MazeConfig): Stored maze configuration.
            __exit (Tuple[int, int]): Exit coordinates in the actual maze grid
            (scaled by 2 + 1).
            __entry (Tuple[int, int]): Entry coordinates in the actual maze
            grid (scaled by 2 + 1).
            __maze (List[List[str]]): 2D grid representation of the maze
            initialized with walls ('#').
            __gen_maze: Generated maze result from the generation algorithm.
            __res_algo (IResolutionAlgo): Resolution algorithm instance for
            solving the maze.

        Notes:
            - If a seed is provided in config, the random number generator is
            seeded for reproducibility.
            - The maze dimensions are scaled by (2 * dimension + 1) to
            accommodate walls between cells.
            - Entry and exit points are marked with '*' in the initial maze
            grid.
        """
        self.__config = config
        if config.seed is not None:
            random.seed(config.seed)
        x, y = config.exit_coord
        self.__exit = (x * 2 + 1, y * 2 + 1)
        x, y = config.entry_coord
        self.__entry = (x * 2 + 1, y * 2 + 1)
        self.__maze: List[List[str]] = [
            list("#" * (config.width * 2 + 1))
            for _ in range(config.height * 2 + 1)
        ]
        self.__maze[self.__entry[1]][self.__entry[0]] = "*"
        self.__maze[self.__exit[1]][self.__exit[0]] = "*"
        self.__maze = self.__draw_forty_two(self.__maze)
        self.__gen_maze = generation_algo.generate(
            self.__entry,
            self.__exit,
            self.__maze,
        )
        self.__res_algo: IResolutionAlgo = resolution_algo

    @property
    def maze(self) -> List[List[str]]:
        """
        Get a deep copy of the maze grid.

        Returns:
            List[List[str]]: A deep copy of the internal maze representation
            as a 2D list of strings.
                This prevents external modification of the internal maze state.
        """
        return deepcopy(self.__maze)

    @property
    def path(self) -> str:
        """
        Get the path of the maze.

        Returns:
            str: The path string representing the maze.
        """
        return self.__path

    @staticmethod
    def get_config(path: str) -> MazeConfig | None:
        """
        Load and parse maze configuration from a dotenv file.

        This function reads environment variables from a specified dotenv file
        and constructs a MazeConfig object with the loaded values.

        Args:
            path (str): The file path to the dotenv configuration file.

        Returns:
            MazeConfig | None: A MazeConfig object if the configuration is
            valid,
                               None if the file is not found or validation
                               fails.

        Environment Variables Expected:
            HEIGHT: The height of the maze (required)
            WIDTH: The width of the maze (required)
            ENTRY: The entry coordinates as comma-separated values (required)
            EXIT: The exit coordinates as comma-separated values (required)
            OUTPUT_FILE: The output file path for the maze (required)
            PERFECT: Boolean flag for perfect maze generation (optional,
            defaults to True)
            VISUALIZE: Boolean flag to enable visualization (optional,
            defaults to False)
            SEED: Random seed for maze generation (optional)

        Raises:
            Prints error messages to stderr for:
            - File not found
            - ValidationError: Invalid configuration values
            - AttributeError: Missing ENTRY or EXIT variables

        Note:
            Type ignore comments are used throughout to suppress type checking
            warnings
            for os.getenv() return values, which can be None.
        """
        if not dotenv.load_dotenv(path):
            print("File not found", file=sys.stderr)
            return None
        try:

            return MazeConfig(
                height=os.getenv("HEIGHT"),
                width=os.getenv("WIDTH"),
                entry_coord=tuple(
                    (os.getenv("ENTRY") or "").split(","),
                ),
                exit_coord=tuple(
                    (os.getenv("EXIT") or "").split(","),
                ),
                output_file=os.getenv("OUTPUT_FILE"),
                perfect=(
                    os.getenv("PERFECT")
                    if os.getenv("PERFECT") is not None
                    else True
                ),
                visualize=(
                    os.getenv("VISUALIZE")
                    if os.getenv("VISUALIZE") is not None
                    else False
                ),
                seed=os.getenv("SEED"),
            )
        except ValidationError as e:
            if len(e.errors()[0]["loc"]) > 0:
                print(
                    f"{str(e.errors()[0]['loc'][0]).upper()}: ",
                    end="",
                    file=sys.stderr,
                )
            print(e.errors()[0]["msg"], file=sys.stderr)
        except AttributeError:
            print(
                "Missing "
                f"{'ENTRY' if os.getenv('ENTRY') is None else 'EXIT'}"
                " in config file",
                file=sys.stderr,
            )
        return None

    def __draw_forty_two(self, maze: List[List[str]]) -> List[List[str]]:
        """
        Draws the number '42' pattern in the center of the maze using
        asterisks.

        This method places asterisks (*) in the maze to form the visual
        representation
        of the number '42'. The pattern is centered in the maze and requires a
        minimum
        maze size of 6 rows and 8 columns.

        Args:
            maze (List[List[str]]): A 2D list representing the maze grid where
            the
                                   pattern will be drawn.

        Returns:
            List[List[str]]: The modified maze with the '42' pattern drawn in
            the center.
                            If the maze is too small (height < 6 or width < 8),
                            returns
                            the original maze unchanged and prints a warning
                            message.

        Note:
            - The pattern is positioned at odd-indexed coordinates to ensure
            proper
              alignment within the maze structure.
            - The minimum required dimensions are height >= 6 and width >= 8.
        """
        if self.__config.height < 6 or self.__config.width < 8:
            print("Maze too small for the 42 pattern")
            return maze
        index_y = len(maze) // 2 - 4
        index_x = len(maze[0]) // 2 - 5
        if index_x % 2 == 0:
            index_x -= 1
        if index_y % 2 == 0:
            index_y -= 1
        for _ in range(3):
            maze[index_y][index_x] = "*"
            index_y += 2
        index_y -= 2
        maze[index_y][(index_x := index_x + 2)] = "*"
        index_x += 2
        for _ in range(3):
            maze[index_y][index_x] = "*"
            index_y += 2
        index_y = len(maze) // 2 - 4
        index_x = len(maze[0]) // 2 + 3
        if index_x % 2 == 0:
            index_x -= 1
        if index_y % 2 == 0:
            index_y -= 1
        for _ in range(3):
            maze[index_y][index_x] = "*"
            index_x += 2
        index_x -= 2
        maze[(index_y := index_y + 2)][index_x] = "*"
        index_y += 2
        for _ in range(3):
            maze[index_y][index_x] = "*"
            index_x -= 2
        index_x += 2
        maze[(index_y := index_y + 2)][index_x] = "*"
        index_y += 2
        for _ in range(3):
            maze[index_y][index_x] = "*"
            index_x += 2
        return maze

    def __to_hexa(self, maze: List[List[str]]) -> List[str]:
        """
        Convert a 2D maze representation to a hexadecimal format.

        This method converts a maze grid into a compact hexadecimal
        representation by examining
        4-directional neighbors (up, right, down, left) of each cell at odd
        coordinates and
        encoding their wall status as a 4-bit binary number, then converting
        to hexadecimal.

        Args:
            maze (List[List[str]]): A 2D list representing the maze where "#"
            represents walls
                                   and other characters represent open spaces.

        Returns:
            List[str]: A list of hexadecimal strings (uppercase, without '0x'
            prefix) where each
                      string represents the wall configuration of a cell. Each
                      hex digit encodes:
                      - bit 3 (MSB): top neighbor is wall (1) or not (0)
                      - bit 2: right neighbor is wall (1) or not (0)
                      - bit 1: bottom neighbor is wall (1) or not (0)
                      - bit 0 (LSB): left neighbor is wall (1) or not (0)

        Note:
            The method iterates through the maze at intervals of 2 (starting
            from index 1),
            sampling cells at (y, x) where both coordinates are odd numbers.
        """
        index_y: int = 1
        hexa_maze: List[str] = []
        while index_y < self.__config.height * 2 + 1:
            nb: List[str] = list(4 * "0")
            index_x: int = 1
            while index_x < self.__config.width * 2 + 1:
                nb[3] = "1" if maze[index_y - 1][index_x] == "#" else "0"
                nb[2] = "1" if maze[index_y][index_x + 1] == "#" else "0"
                nb[1] = "1" if maze[index_y + 1][index_x] == "#" else "0"
                nb[0] = "1" if maze[index_y][index_x - 1] == "#" else "0"
                hexa_maze.append(hex(int("".join(nb), 2))[2:].upper())
                index_x += 2
            index_y += 2
        return hexa_maze

    def __cells_neigbours(self, y: int, x: int) -> List[Tuple[int, int]]:
        """
        Get the valid neighboring cells of a given cell in the maze.

        Args:
            y (int): The row index of the cell.
            x (int): The column index of the cell.

        Returns:
            List[Tuple[int, int]]: A list of tuples containing the (x, y)
            coordinates
                                   of valid neighboring cells. Neighbors are
                                   checked
                                   in the order: up, left, right, down. Only
                                   neighbors
                                   that are within the maze boundaries
                                   excluding the
                                   outer walls) are included.
        """
        to_get: List[Tuple[int, int]] = [
            (-1, 0),
            (0, -1),
            (0, 1),
            (1, 0),
        ]
        return [
            (x + dx, y + dy)
            for dx, dy in to_get
            if 0 < x + dx < len(self.__maze[y]) - 1
            and 0 < y + dy < len(self.__maze) - 1
        ]

    def __create_imperfection(self) -> None:
        """
        Create imperfections in the maze by randomly converting walls to a
        different marker.

        This method adds randomness to the maze structure in two phases:
        1. First phase: Iterates through cells at odd indices and examines
        their neighbors.
            For neighbors outside a defined rectangular region (centered
            around the maze),
            walls have a 15% chance of being converted to '*' markers.
        2. Second phase: Iterates through all cells and identifies isolated
        walls (walls
            with no adjacent walls). These isolated walls have a 50% chance of
            being
            converted to '*' markers.

        The protected rectangular region is calculated based on the maze
        center with
        dimensions approximately 16x12 cells.

        Returns:
             None: This method modifies the maze in-place.

        Notes:
             - Uses the `__cells_neigbours` method to get adjacent cells.
             - '#' represents walls in the maze.
             - '*' represents imperfect/breakable walls.
        """
        index_y = len(self.__maze) // 2 - 4
        index_x = len(self.__maze[0]) // 2 - 5
        if index_x % 2 == 0:
            index_x -= 1
        if index_y % 2 == 0:
            index_y -= 1
        for i in range(1, len(self.__maze) - 1, 2):
            for j in range(1, len(self.__maze[i]) - 1, 2):
                for x, y in self.__cells_neigbours(i, j):
                    if (y >= index_y - 1 and y <= index_y + 10) and (
                        x >= index_x - 1 and x <= index_x + 14
                    ):
                        continue
                    if self.__maze[y][x] == "#" and random.random() < 0.15:
                        self.__maze[y][x] = "*"
        for i in range(1, len(self.__maze) - 1):
            for j in range(1, len(self.__maze[i]) - 1):
                if self.__maze[i][j] != "#":
                    continue
                wall = 0
                for x, y in self.__cells_neigbours(i, j):
                    if self.__maze[y][x] == "#":
                        wall += 1
                if wall == 0 and random.random() < 0.5:
                    self.__maze[i][j] = "*"

    def __generation_animation(self, line: List[str]) -> None:
        """
        Print a single line of the maze generation animation with color
        formatting.

        This method takes a line of maze characters and prints it with ANSI
        color codes:
        - '*' characters are printed with default colors (reset)
        - '#' characters are printed with white background
        - Other characters are printed as-is

        Args:
            line (List[str]): A list of characters representing one line of
            the maze,
                             where '*' represents visited cells, '#'
                             represents walls,
                             and other characters represent different cell
                             states.

        Returns:
            None: This method prints directly to stdout and returns nothing.
        """
        print(
            "".join(
                list(
                    map(
                        lambda x: (
                            "\033[0m \033[0m"
                            if x == "*"
                            else ("\033[47m \033[0m" if x == "#" else x)
                        ),
                        line,
                    )
                )
            )
        )

    def generate(self) -> Tuple[List[str], str]:
        """
        Generate a maze and find a path from entry to exit.

        This method runs the maze generation algorithm and optionally
        visualizes the process.
        After generation, it can introduce imperfections if configured, then
        resolves a path
        from the entry point to the exit point.

        Returns:
            Tuple[List[str], str]: A tuple containing:
                - List[str]: The generated maze in hexadecimal representation
                - str: The path from entry to exit as a string

        Raises:
            StopIteration: Internally caught to retrieve the final maze value
            from the generator

        Notes:
            - If visualization is enabled (self.__config.visualize), the maze
            generation
              is displayed with a 0.01 second delay between frames and screen
              clearing
            - If the maze is not configured to be perfect
            (self.__config.perfect is False),
              imperfections are added via self.__create_imperfection()
            - The path resolution uses the configured resolution algorithm
            (self.__res_algo)
        """
        if not self.__config.visualize:
            while True:
                try:
                    for _ in next(self.__gen_maze):
                        pass
                except StopIteration as it:
                    self.__maze = it.value
                    break
        else:
            while True:
                try:
                    for i in next(self.__gen_maze):
                        self.__generation_animation(i)
                    time.sleep(0.03)
                    os.system("cls" if os.name == "nt" else "clear")
                except StopIteration as it:
                    self.__maze = it.value
                    break
        if not self.__config.perfect:
            self.__create_imperfection()
        self.__path = self.__res_algo.resolve(
            self.__maze, self.__entry, self.__exit
        )
        return (self.__to_hexa(self.__maze), self.__path)
